from setuptools import setup

setup(name='rfdist',
      version='0.3',
      install_requires=['numpy','ete3','logging']
      )
